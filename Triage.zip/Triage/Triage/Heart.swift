//
//  HeartType.swift
//  Game
//
//  Created by Lherisson Medina on 6/11/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import SpriteKit


enum Priority: Int {
    case  none = 5, red = 1, gold = 2, green = 3, black = 4
    
    func color() -> UIColor {
        switch self {
        case .black:
            return color_Black
        case .red:
            return color_Red
        case .gold:
            return color_Gold
        case .green:
            return color_Green
        case .none:
            return .white
        }
    }
    
    func points() -> (tapPoints: Int, crashPoints: Int) {
        switch self {
        case .red:
            return (5, -50)
        case .gold:
            return (3, -30)
        case .green:
            return (2, -20)
        case .black:
            return (1, -10)
        case .none:
            return (0, -0)
        }
    }
}

class Heart: Shape {
    
    var explosionStrength: Float!
    var points: (tapPoints: Int, crashPoints: Int)!
    let deathAction = SKAction.sequence([SKAction.group([SKAction.fadeOut(withDuration: 0.2), SKAction.scale(to: 0, duration: 0.2)]), SKAction.removeFromParent()])
    
    var priority: Priority! {
        didSet {
            self.run(SKAction.colorize(with: priority.color(), colorBlendFactor: 1, duration: 0.5))
            self.action(forKey: "HeartBeat")?.speed = CGFloat(-0.4 * Double(priority.rawValue) + 2)
            self.explosionStrength = Float(-priority.rawValue + 3)
            self.points = priority.points()
        }
    }
    
    convenience init(_ priority: Priority) {
        self.init(image: SKTexture(imageNamed: "Heart"), color: priority.color())
        self.priority = priority
        self.name = "Heart"
        
        self.run(SKAction(named: "Heart Beat")!, withKey: "HeartBeat")
        self.action(forKey: "HeartBeat")?.speed = CGFloat(-0.4 * Double(priority.rawValue) + 2)
        
        self.explosionStrength = Float(-priority.rawValue + 3)
        self.points = priority.points()
        
        addPhysics(size: CGSize(width: 50, height: 50))
    }
    
    func transform() {
        if let priority = Priority(rawValue: self.priority.rawValue - 1) {
            self.priority = priority
        }
    }
    
    func die() {
        self.physicsBody = nil
        self.removeAllActions()
        self.run(deathAction)
    }
    
}
