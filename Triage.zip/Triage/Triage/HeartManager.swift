//
//  ShapeManager.swift
//  Triage
//
//  Created by Lherisson Medina on 9/11/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit

class HeartManager {
    var hearts = [Heart]()
    
    func getHeart() -> Shape {
        var shape: Shape?
        let randomNum = Int(arc4random_uniform(5))
        if let priority = Priority(rawValue: randomNum) {
            shape = Heart(priority)
            //shapes.append(shape!)
        }
        return shape ?? Heart(.red)
    }
    
    func removeHearts(heartsToRemove: [Heart]) {
        for heart in heartsToRemove{
            if let index = hearts.index(of: heart) {
                hearts.remove(at: index)
                /*let priority = hearts.remove(at: index).priority!
                for remainingShape in hearts.filter({$0.priority.rawValue < priority.rawValue}){
                    remainingShape.transform()
                }*/
            }
        }
    }
}
