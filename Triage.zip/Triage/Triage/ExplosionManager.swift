//
//  ExplosionManager.swift
//  Triage
//
//  Created by Lherisson Medina on 9/15/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import SpriteKit

class ExplosionManager {
    enum ExplosionType: String {
        case TapExplosion
        case CrashExplosion
    }
    
    let crashEmitter = SKEmitterNode(fileNamed: "CrashExplosion")!
    let tapEmitter = SKEmitterNode(fileNamed: "TapExplosion")!
    let shockwave = SKFieldNode.radialGravityField()
    let deathAction = SKAction.sequence([SKAction.wait(forDuration: 3), SKAction.removeFromParent()])
    let soundNode = SKAudioNode(fileNamed: "Break")
    
    init() {
        shockwave.minimumRadius = 20
        shockwave.run(SKAction.sequence([SKAction.strength(to: 0, duration: 0.3), SKAction.removeFromParent()]))
        crashEmitter.run(deathAction)
        tapEmitter.run(deathAction)
        tapEmitter.particleColorSequence = nil
        soundNode.autoplayLooped = false
    }
    
    func crashExplosion(in parent: SKNode, hearts: [Heart]) {
        for heart in hearts {
            heart.die()
            let emitter = crashEmitter.copy() as! SKEmitterNode
            let wave = shockwave.copy() as! SKFieldNode
        
            emitter.particleColor = .black
            emitter.position = heart.position
            emitter.position.y -= heart.size.height
            wave.strength = heart.explosionStrength
            wave.position = heart.position
        
            parent.addChild(emitter)
            parent.addChild(wave)

            heart.run(SKAction.playSoundFileNamed("Break.wav", waitForCompletion: false))
        }
    }
    
    func tapExplosion(in parent: SKNode, hearts: [Heart]) {
        for heart in hearts {
            heart.die()
            let emitter = tapEmitter.copy() as! SKEmitterNode
            let wave = shockwave.copy() as! SKFieldNode
        
            emitter.particleColor = heart.color
            emitter.position = heart.position
            wave.strength = heart.explosionStrength
            wave.position = heart.position
        
            parent.addChild(emitter)
            parent.addChild(wave)
            heart.run(SKAction.playSoundFileNamed("Break.wav", waitForCompletion: false))
        }
    }
}
