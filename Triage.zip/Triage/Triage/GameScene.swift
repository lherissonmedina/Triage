//
//  GameScene.swift
//  Triage
//
//  Created by Lherisson Medina on 9/11/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import SpriteKit
import GameplayKit
import CoreMotion

class GameScene: SKScene, SKPhysicsContactDelegate {
    var motionManager = CMMotionManager()
    var heartManager = HeartManager()
    var explosionManager = ExplosionManager()
    
    var shockwave = SKFieldNode.radialGravityField()
    var menuBar: MenuBar!
    let averageTimeBetweenHearts: TimeInterval = 0.5
    
    //-----------------------------------------------------------
    // MARK: didMoveToView
    //-----------------------------------------------------------
    override func didMove(to view: SKView) {
        menuBar = MenuBar(width: view.frame.width)
        self.backgroundColor = color_Background
        view.addSubview(menuBar)

        addPhysics()
        readyShockwave()
        startDropping()
    }
    
    func startDropping() {
        let action = SKAction.repeatForever(SKAction.sequence([SKAction.wait(forDuration: averageTimeBetweenHearts, withRange: 1), SKAction.run({
            let heart = self.heartManager.getHeart()
            let num = CGFloat(GKARC4RandomSource().nextUniform())
            heart.position.x = (self.size.width - 100)*(num - 0.5)
            heart.position.y = (self.size.height/2)
            heart.zRotation = num*2*CGFloat(M_PI)
            self.addChild(heart)
        })]))
        self.run(action)
    }
    
    func readyShockwave() {
        shockwave.strength = -2
        shockwave.minimumRadius = 20
        shockwave.run(SKAction.sequence([SKAction.strength(to: 0, duration: 0.1), SKAction.removeFromParent()]))
    }
    
    //-----------------------------------------------------------
    // MARK: Physics
    //-----------------------------------------------------------
    func addPhysics() {
        self.physicsWorld.contactDelegate = self;
        motionManager.startAccelerometerUpdates()
        motionManager.accelerometerUpdateInterval = 0.5
        
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -1);
        let rect = CGRect(x: self.frame.minX, y: self.frame.minY, width: self.size.width, height: self.size.height + 20)
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: rect)
        
        let spikes = self.childNode(withName: "Spikes") as! SKSpriteNode
        spikes.size.width = self.size.width
        spikes.position.y = -self.size.height/2 + spikes.size.height/2
        spikes.physicsBody!.contactTestBitMask = spikes.physicsBody!.collisionBitMask
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        
        let bodyA = contact.bodyA, bodyB = contact.bodyB
        
        if let heart = bodyA.node as? Heart {
            collision(heart, bodyB: bodyB.node,impulse: contact.collisionImpulse)
        } else if let heart = bodyB.node as? Heart {
            collision(heart, bodyB: bodyA.node, impulse: contact.collisionImpulse)
        }
    }
    
    func collision(_ heart: Heart, bodyB: SKNode?, impulse: CGFloat) {
        if let _ = bodyB as? SKSpriteNode , bodyB?.name == "Spikes" {
            let _ = menuBar.updateScore(by: heart.points.crashPoints)
            explosionManager.crashExplosion(in: self, hearts: [heart])
            //shapeManager.removeShapes(shapesToRemove: [shape])
        } else if let heart2 = bodyB as? Heart , impulse > 90 {
            let _ = menuBar.updateScore(by: heart.points.tapPoints + heart2.points.tapPoints)
            explosionManager.tapExplosion(in: self, hearts: [heart, heart2])
            //shapeManager.removeShapes(shapesToRemove: [shape, shape2])
        }
    }
    
    //-----------------------------------------------------------
    // MARK: touchesBegan
    //-----------------------------------------------------------
    override func touchesBegan(_ touches: Set<UITouch>, with withEvent: UIEvent?) {
        if menuBar.isPaused() { return }
        
        for touch in touches {
            let location = touch.location(in: self)
            
            for shape in self.nodes(at: location) {
                if let heart = shape as? Heart {
                    let _ = menuBar.updateScore(by: heart.points.tapPoints)
                    explosionManager.tapExplosion(in: self, hearts: [heart])
                    //shapeManager.removeShapes(shapesToRemove: [heart])
                }
            }
            
            if let wave = self.shockwave.copy() as? SKFieldNode {
                wave.position = location
                self.addChild(wave)
            }
            
        }
    }
    
    //-----------------------------------------------------------
    // MARK: touchesEnded
    //-----------------------------------------------------------
    override func touchesEnded(_ touches: Set<UITouch>, with withEvent: UIEvent?) {
        
    }
    
    //-----------------------------------------------------------
    // MARK: touchesMoved
    //-----------------------------------------------------------
    override func touchesMoved(_ touches: Set<UITouch>, with withEvent: UIEvent?) {
 
    }
    
    //-----------------------------------------------------------
    // MARK: update
    //-----------------------------------------------------------
    override func update(_ currentTime: TimeInterval) {
        if menuBar.isPaused() { isPaused = true; return }
        
        if let accelerometerData = motionManager.accelerometerData {
            let yAcceleration = accelerometerData.acceleration.y < -0.3 ? accelerometerData.acceleration.y * 1.5 : -0.3
            physicsWorld.gravity = CGVector(dx: accelerometerData.acceleration.x, dy: yAcceleration)
        }
    }
}
