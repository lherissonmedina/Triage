//
//  ColorConstants.swift
//  Game
//
//  Created by Lherisson Medina on 6/12/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import UIKit.UIColor

let color_Red = UIColor(red: 255/255, green: 126/255, blue: 121/255, alpha: 1)
let color_Black = UIColor(red: 0.3, green: 0.3, blue: 0.3, alpha: 1)
let color_Green = UIColor(red: 140/255, green: 180/255, blue: 80/255, alpha: 1)
let color_Gold = UIColor(red: 0.94, green: 0.77, blue: 0.03, alpha: 1)

var color_Background: UIColor = UIColor(red: 255/255, green: 212/255, blue: 187/255, alpha: 1)
var color_Foreground: UIColor = UIColor(red: 255/255, green: 126/255, blue: 121/255, alpha: 1)

var color_Background_Highlighted: UIColor = UIColor(red: 235/255, green: 292/255, blue: 167/255, alpha: 1)
var color_Foreground_Highlighted: UIColor = UIColor(red: 235/255, green: 106/255, blue: 101/255, alpha: 1)
