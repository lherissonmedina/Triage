//
//  Heart.swift
//  Game
//
//  Created by Lherisson Medina on 4/24/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import SpriteKit

class Shape: SKSpriteNode {
    
    init(image: SKTexture?, color: UIColor) {
        super.init(texture:  image, color: color, size: CGSize(width: 1, height: 1))
        self.name = "Shape"
        self.colorBlendFactor = 1
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addPhysics(size: CGSize) {
        self.physicsBody = SKPhysicsBody(texture: self.texture!, size: size)
        self.physicsBody?.isDynamic = true
        self.physicsBody?.mass = 0.5
        self.physicsBody!.contactTestBitMask = self.physicsBody!.collisionBitMask
    }
    
}
