//
//  ScoreBoard.swift
//  Falling Hearts
//
//  Created by Lherisson Medina on 6/25/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import UIKit

class NumberLabel: UILabel {
    
    init(size: CGSize = CGSize(width: 0, height: 40)) {
        super.init(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: size))
        
        self.translatesAutoresizingMaskIntoConstraints = false
        
        self.font = UIFont.systemFont(ofSize: 30, weight: 0)
        self.textColor = color_Foreground
        self.textAlignment = .center
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
