//
//  MenuBar.swift
//  Triage
//
//  Created by Lherisson Medina on 9/11/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import UIKit

class MenuBar: UIView {
    private let scoreLabel: NumberLabel = NumberLabel()
    private let pausedButton: Button = Button(size: 30, text: "PAUSED", backgroundColor: color_Foreground)
    private let tapButton: Button = Button(size: 10, text: "TAP TO PAUSE")
    private let resetButton: Button = Button(size: 15, text: "Reset", backgroundColor: color_Black)
    private let lowerBorder: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
    
    private let back = UIVisualEffectView(effect: UIBlurEffect(style: .light))
    private let helpImage = UIImageView(image: #imageLiteral(resourceName: "InfoPane"))
    private var paused = true
    
    let scoreManager = ScoreManager()
    
    private var mode: Mode = .compact {
        didSet {
            switch (oldValue, mode) {
            case (_, .compact):
                changePause(to: false)
                pausedButton.hide()
                tapButton.show()
                self.snap(to: frame_Compact)
            case (.compact, _):
                changePause(to: true)
                pausedButton.show()
                tapButton.hide()
                fallthrough
            default:
                if oldValue != .paused && mode == .paused {
                    self.snap(to: frame_Paused)
                } else if mode == .full {
                    if scoreManager.currentScore != 0 {
                        resetButton.show()
                    } else {
                        resetButton.hide()
                    }
                    
                    snap(to: frame_Full)
                }
            }
        }
    }
    
    private let spacing: CGFloat = 10
    private let margin: CGFloat = 10
    private let fullWidth: CGFloat
    
    private var height_compact: CGFloat { return margin*2 + scoreLabel.frame.height + spacing }
    private var height_paused: CGFloat { return height_compact + pausedButton.frame.height }
    private var height_full: CGFloat { return height_paused + spacing + helpImage.frame.height + spacing + resetButton.frame.height }
    enum Mode { case compact, paused, full }
    
    private var frame_Compact: CGRect { return  CGRect(x: 0, y: 0, width: fullWidth, height: height_compact)}
    private var frame_Paused: CGRect { return CGRect(x: 0, y: 0, width: fullWidth, height: height_paused) }
    private var frame_Full: CGRect { return CGRect(x: 0, y: 0, width: fullWidth*0.9, height: height_full) }
    
    //-----------------------------------------------------------
    // MARK: Init
    //-----------------------------------------------------------
    init(width: CGFloat) {
        fullWidth = width
        super.init(frame: CGRect(x: 0, y: 0, width: width, height: 0))
        
        lowerBorder.backgroundColor = color_Foreground
        lowerBorder.alpha = 0.3
        
        self.layer.masksToBounds = true
        self.addSubview(back)
        self.addSubview(scoreLabel)
        self.addSubview(tapButton)
        self.addSubview(pausedButton)
        self.addSubview(lowerBorder)
        self.addSubview(helpImage)
        self.addSubview(resetButton)
        
        scoreLabel.text = scoreManager.getScoreAsString()
        setConstraints()
        addGestureRecognizers()
    }
    
    func addGestureRecognizers() {
        tapButton.addTarget(self, action: #selector(MenuBar.pauseButtonTapped), for: .touchUpInside)
        resetButton.addTarget(self, action: #selector(MenuBar.resetButtonTapped), for: .touchUpInside)
        pausedButton.addTarget(self, action: #selector(MenuBar.pausedButtonTapped), for: .touchUpInside)
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(MenuBar.pan))
        self.addGestureRecognizer(panGesture)
    }
    
    func setConstraints() {
        scoreLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: margin).isActive = true
        //scoreLabel.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        scoreLabel.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        
        tapButton.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        tapButton.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        
        pausedButton.topAnchor.constraint(equalTo: scoreLabel.bottomAnchor, constant: spacing).isActive = true
        pausedButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.8).isActive = true
        pausedButton.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        
        helpImage.translatesAutoresizingMaskIntoConstraints = false
        helpImage.topAnchor.constraint(equalTo: pausedButton.bottomAnchor, constant: spacing).isActive = true
        helpImage.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        helpImage.heightAnchor.constraint(equalTo: helpImage.widthAnchor, multiplier: 0.4).isActive = true
        helpImage.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.5).isActive = true
        
        resetButton.topAnchor.constraint(equalTo: helpImage.bottomAnchor, constant: spacing).isActive = true
        resetButton.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        resetButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 0.5).isActive = true
        
        lowerBorder.translatesAutoresizingMaskIntoConstraints = false
        lowerBorder.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        lowerBorder.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        lowerBorder.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        lowerBorder.heightAnchor.constraint(equalToConstant: 1).isActive = true
        
        back.translatesAutoresizingMaskIntoConstraints = false
        back.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        back.heightAnchor.constraint(equalTo: self.heightAnchor).isActive = true
        back.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        back.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        
    }
    
    func pauseButtonTapped() {
        mode = .paused
    }
    
    func pausedButtonTapped() {
        mode = .compact
    }
    
    func resetButtonTapped() {
        let _ = scoreManager.updateScore(to: 0)
        scoreLabel.text = scoreManager.getScoreAsString()
        scoreManager.saveScore()
        resetButton.hide()
        mode = .full
    }
    
    func pan(recognizer: UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: self).y
        
        switch recognizer.state {
        case .began:
            break
        case .changed:
            if mode != .full && translation > 40 {
                mode = .full
                recognizer.isEnabled = false
            } else if mode == .full {
                if self.center.y <= 540 {
                    let translationFromCenter =  superview!.center.y + translation
                    self.center.y = translationFromCenter
                }
                
                if self.center.y < 300 {
                    if recognizer.velocity(in: self).y < -1100 {
                        mode = .compact
                    } else {
                        mode = .paused
                    }
                    recognizer.isEnabled = false
                }
            }
        case .ended:
            mode = .full
        default:
            break
        }
        recognizer.isEnabled = true
    }
    
    func snap(to rect: CGRect) {
        
        UIViewPropertyAnimator(duration: 1, dampingRatio: 0.6, animations: {
            self.frame = rect
            self.layoutIfNeeded()
            if self.mode == .full {
                self.center = self.superview!.center
                self.layer.cornerRadius = 10
                self.layer.borderWidth = 1
                self.layer.borderColor = color_Foreground.cgColor
            } else {
                self.layer.cornerRadius = 0
                self.layer.borderWidth = 0
            }

        }).startAnimation()
    }
    
    func updateScore(by amount: Int) {
        let _ = scoreManager.updateScore(by: amount)
        scoreLabel.text = scoreManager.getScoreAsString()
    }
    
    //-----------------------------------------------------------
    // MARK: Pausing
    //-----------------------------------------------------------
    private func changePause(to pause: Bool) {
        paused = pause
        NotificationCenter.default.post(name: Notification.Name(rawValue: scoreNotificationKey), object: self, userInfo: nil)
    }
    
    func changeMode(to mode: Mode) {
        self.mode = mode
    }
    
    func isPaused() -> Bool { return paused }
    
    
    required init(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
}
