//
//  Button.swift
//  Triage
//
//  Created by Lherisson Medina on 9/17/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import UIKit

class Button: UIButton {
    
    var isShowing: Bool = true
    
    override var isHighlighted: Bool {
        didSet {
            if isHighlighted {
                if let currentColor = color {
                    var hue = CGFloat()
                    var saturation = CGFloat()
                    var brightness = CGFloat()
                    currentColor.getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: nil)
                    backgroundColor = UIColor.init(hue: hue, saturation: saturation, brightness: brightness - 0.1, alpha: 1)
                }
            } else {
                backgroundColor = color
            }
        }
    }
    
    let color: UIColor?
    
    init(size: CGFloat = 40, text: String = "", backgroundColor: UIColor? = nil) {
        color = backgroundColor
        super.init(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: 0, height: 50)))
        
        self.translatesAutoresizingMaskIntoConstraints = false
        
        self.setTitle(text, for: .normal)
        self.titleLabel?.font = UIFont.systemFont(ofSize: size, weight: 1)
        
        if let background = backgroundColor {
            self.setTitleColor(color_Background, for: .normal)
            self.backgroundColor = background
            self.layer.masksToBounds = true
            self.layer.cornerRadius = size/6
        } else {
            self.setTitleColor(color_Foreground, for: .normal)
            
            var hue = CGFloat()
            var saturation = CGFloat()
            var brightness = CGFloat()
            self.titleColor(for: .normal)?.getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: nil)
            self.setTitleColor(UIColor(hue: hue, saturation: saturation, brightness: brightness - 0.1, alpha: 1), for: .highlighted)
        }
    }
    
    func show() {
        UIViewPropertyAnimator(duration: 0.8, dampingRatio: 0.6, animations: {
            self.transform = CGAffineTransform(scaleX: 1, y: 1)
            self.alpha = 1
        }).startAnimation()
        isShowing = true
    }
    
    func hide() {
        UIViewPropertyAnimator(duration: 0.8, dampingRatio: 0.6, animations: {
            self.transform = CGAffineTransform(scaleX: 0.3, y: 0.3)
            self.alpha = 0
        }).startAnimation()
        isShowing = false
    }
    
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}
