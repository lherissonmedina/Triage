//
//  NotificationKeys.swift
//  Falling Hearts
//
//  Created by Lherisson Medina on 6/25/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

let scoreNotificationKey = "com.lherissmedina.ScoreNotificationKey"
