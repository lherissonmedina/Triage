//
//  ScoreManager.swift
//  Game
//
//  Created by Lherisson Medina on 6/12/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import UIKit

class ScoreManager {
    
    internal var currentScore: Int = 0
    let numberFormatter = NumberFormatter()
    
    init () {
        let _ = updateScore(by: loadScore()?.score ?? 0)
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
    }
    
    func getScoreAsString() -> String { return "\(numberFormatter.string(from: NSNumber(value: currentScore))!)" }
    
    //-----------------------------------------------------------
    // MARK: Changing Scores
    //-----------------------------------------------------------
    
    func updateScore(by points:Int) -> Int {
        currentScore += points
        return currentScore
    }
    
    func updateScore(to points: Int) -> Int {
        currentScore = points
        return currentScore
    }
    
    func saveScore() {
        saveScore(currentScore)
    }
    
    //-----------------------------------------------------------
    // MARK: Loading and Saving Scores
    //-----------------------------------------------------------
    private func loadScore() -> Score? {
        return NSKeyedUnarchiver.unarchiveObject(withFile: Score.ArchiveURL.path) as? Score
    }
    
    private func saveScore(_ currentScore: Int){
        let session = Score(player: "Lherisson", score: currentScore)
        NSKeyedArchiver.archiveRootObject(session!, toFile: Score.ArchiveURL.path)
    }
    
    
}
