//
//  Score.swift
//  Game
//
//  Created by Lherisson Medina on 4/23/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation

class Score: NSObject, NSCoding {
    var player: String
    var score: Int
    
    static let DocumentDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    
    static let ArchiveURL = DocumentDirectory.appendingPathComponent("scores")
    
    
    struct PropertyKey {
        static let playerKey = "player"
        static let scoreKey = "score"
    }
    
    init? (player: String, score: Int) {
        self.player = player
        self.score = score
        
        super.init()
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(player, forKey: PropertyKey.playerKey)
        aCoder.encode(score, forKey: PropertyKey.scoreKey)
    }
    
    required convenience init?(coder aDecoder: NSCoder){
        let player = aDecoder.decodeObject(forKey: PropertyKey.playerKey) as! String
        let score = aDecoder.decodeInteger(forKey: PropertyKey.scoreKey)
        
        self.init(player: player, score: score)
    }
}
