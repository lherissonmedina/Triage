//
//  GameViewController.swift
//  Triage
//
//  Created by Lherisson Medina on 9/11/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(GameViewController.pauseGame), name: NSNotification.Name(rawValue: scoreNotificationKey), object: nil)
        
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            if let scene = SKScene(fileNamed: "GameScene") {
                // Set the scale mode to scale to fit the window
                
                scene.size = view.bounds.size
                scene.scaleMode = .resizeFill
                // Present the scene
                view.presentScene(scene)
                
                (scene as? GameScene)?.menuBar.changeMode(to: .paused)
            }
            
            view.ignoresSiblingOrder = true
            view.showsFPS = false
            view.showsNodeCount = false
        }
    }
    
    func pauseGame() {
        if let view = self.view as! SKView? {
            if let scene = view.scene as? GameScene {
                scene.isPaused = scene.menuBar.isPaused()
            }
        }
    }

    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    
}
