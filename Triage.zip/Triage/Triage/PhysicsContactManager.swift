//
//  PhysicsContactManager.swift
//  Triage
//
//  Created by Lherisson Medina on 9/11/16.
//  Copyright © 2016 Lherisson Medina. All rights reserved.
//

import Foundation
import SpriteKit

class PhysicsContactManager: SKPhysicsContactDelegate {
    let view: SKScene
    let scoreManger: ScoreManagerDelegate
    
    init(view: SKScene, scoreManager: ScoreManagerDelegate) {
        self.view = view
        self.scoreManger = scoreManager
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let bodyA = contact.bodyA, bodyB = contact.bodyB
        
        if let shape = bodyA.node as? Shape {
            collision(shape, bodyB: bodyB.node,impulse: contact.collisionImpulse)
        } else if let shape = bodyB.node as? Shape {
            collision(shape, bodyB: bodyA.node, impulse: contact.collisionImpulse)
        }
    }
    
    func collision(_ shape: Shape, bodyB: SKNode?, impulse: CGFloat) {
        if let _ = bodyB as? SKSpriteNode , bodyB?.name == "Spikes" {
            let _ = scoreManger.updateScore(by: shape.points.crashPoints)
            shape.explode(view, type: .crash)
            
        } else if let shape2 = bodyB as? Shape , impulse > 90 {
            let _ = scoreManger.updateScore(by: shape.points.tapPoints + shape2.points.tapPoints)
            shape.explode(view, type: .collision)
            shape2.explode(view, type: .collision)
        }
    }
    
    
}
